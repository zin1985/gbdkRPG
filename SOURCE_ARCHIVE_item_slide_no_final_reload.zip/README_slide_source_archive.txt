This archive preserves the previous dynamic window-slide prototype source.
It is included only as a reference artifact and is not used by the active rpg271 build.
